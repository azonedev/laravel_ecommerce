@extends('test.master')


@section('title')
This is section test title
@endsection


@section('main')

<h1>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ea, officia.</h1>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Illo mollitia fugiat, nesciunt quibusdam eveniet ullam quam quas fuga. Est reprehenderit pariatur temporibus facilis voluptates quae quidem repudiandae commodi officiis possimus.</p>

@endsection