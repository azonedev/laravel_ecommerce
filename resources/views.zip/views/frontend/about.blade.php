@extends('welcome')


@section('title')
About us - SHOPMAMA
@endsection

@section('main')


  <div class="section">
      <div class="container">
            <section id="about" class="section_padding">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">

                        <h2 class="text-center" style="padding:25px">About Us</h2>
                    </div>
                    <div class="row">
                        <div class="col-md-6">

                            <div class="about_single">
                                <img style="max-width: 100%" alt="Bootstrap Image Preview" src="https://images.unsplash.com/photo-1556761175-5973dc0f32e7?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=890&q=80">
                            </div>

                        </div>
                        <div class="col-md-6">

                            <div class="about_single">
                               <h3>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsum, laudantium.</h3>
                               <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quibusdam porro doloremque deserunt laborum quos minus, alias perspiciatis, ad repellendus omnis facilis veritatis placeat praesentium quas doloribus quo labore in quasi delectus fugiat! Aliquid facilis, optio quo illum ea laboriosam necessitatibus soluta eaque natus veniam! Quia, odio voluptatibus eum nostrum et repellendus quisquam iusto, consequatur, dicta ad odit minima, veritatis nisi molestias? Molestias accusamus ea magnam, tempora autem vel a, ut quia repudiandae rem et nihil ab minima. Id  harum maiores dicta quaerat deleniti cum alias aspernatur, omnis possimus necessitatibus! Ab nisi voluptas voluptate accusantium unde enim ea amet quasi neque, porro veniam delectus odio, fugit possimus, eaque aperiam reiciendis tempore. Commodi ab labore sit culpa natus voluptas harum id, dolore pariatur. Rerum dolorem laudantium eveniet quos quibusdam deserunt unde deleniti repellat ea. Ipsa.</p>
                            </div>

                        </div>
                    </div>

                </div>
            </div>
        </section>
      </div>
  </div>

@endsection
