    <!-- jQuery Plugins -->
    <script src="{{asset('public/assets/js/jquery.min.js')}}"></script>
    <script src="{{asset('public/assets/js/bootstrap.min.js')}}"></script>
    <script src="{{asset('public/assets/js/slick.min.js')}}"></script>
    <script src="{{asset('public/assets/js/nouislider.min.js')}}"></script>
    <script src="{{asset('public/assets/js/jquery.zoom.min.js')}}"></script>
    <script src="{{asset('public/assets/js/main.js')}}"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>