<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Welcome Mail</title>
</head>
<body>

	<h1>Welcome to laravel One</h1>
	<p>Hi {{$eamil}},<br>
	If you want to login to demo.azonedev.com. You must need to know your password and user login email,so check it and stay happy :) </p>

	<br>

	<h2>Your Login Password Is : 2020{{$subject}}</h2>
	<h2>Your You Email Is : 2020{{$name}}</h2>

</body>
</html>