@extends('welcome')

@section('main')

@endsection